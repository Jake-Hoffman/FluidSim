package game;

import engine.GameEngine;
import engine.IGameLogic;

public class Main {

    public static void main(String[] args){
        try {
            GameEngine gameEng = new GameEngine("Fluid Simulation", 1000, 1000, 100);
            gameEng.start();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }
}
